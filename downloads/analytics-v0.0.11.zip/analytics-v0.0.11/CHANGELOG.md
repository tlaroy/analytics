# v0.1.0
2022-xx-xx

Feature set complete.

# v0.0.12
2022-xx-xx

Secondary Searches.

# v0.0.11
2022-02-24

Actors/Items, Actors/Journals, Actors/Scenes - Search by ID and "Item Macro".
Primary Searches.

# v0.0.10
2022-02-22

Forms - "Item Macro" fields.

# v0.0.9
2022-02-18

Forms - ID fields and show ID in results.

# v0.0.8
2022-02-09

Forms - Cards, Compendiums, Items, Journals, Macros, Playlists, Scenes, Tables, Tiles.

# v0.0.7
2022-02-02

Actors - Labeling and Localization.

# v0.0.6
2022-02-01

Actors - Journal Searches.<br>
Actors - Scene Searches.

# v0.0.5
2022-01-28

Actors - Tabs and Tooltips.

# v0.0.4
2022-01-27

Actors - Item "On Use" Macros.

# v0.0.3
2022-01-25

Actors - Item Options.

# v0.0.2
2022-01-23

Actors - Form.
Actors - Item Searches.

# v0.0.1
2022-01-17

Basic module Settings, Toolbar and placeholder Forms.
