# v0.0.7 (2022-2-2)

* Actors - Clarified labeling.

# v0.0.6 (2022-2-1)

* Actors/Journals and Actors/Scenes.

# v0.0.5 (2022-1-28)

* Actors - Item tooltips.
* Tabs for Actors/Items, Actors/Journals and Actors/Scenes.

# v0.0.4 (2022-1-27)

* Actors - Item On Use Macros.

# v0.0.3 (2022-1-25)

* Actors - Item options.

# v0.0.2 (2022-1-23)

* Actors - Items. D&D5e dependency.

# v0.0.1 (2022-1-17)

* Initial release. Basic module with Settings, Toolbar and placeholder Dialogs.