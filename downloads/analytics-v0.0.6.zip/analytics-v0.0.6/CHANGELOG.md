# v0.0.6 (2022-2-1)

* Actor/Journals and Dialog/Scenes.

# v0.0.5 (2022-1-28)

* Actor Items tooltips.
* Tabs for Actor/Items, Actor/Journal Entries and Actor/Scenes.

# v0.0.4 (2022-1-27)

* Actor Items On Use Macros.

# v0.0.3 (2022-1-25)

* Actor Items Item options.

# v0.0.2 (2022-1-23)

* Actor Items. D&D5e dependency.

# v0.0.1 (2022-1-17)

* Initial release. Basic module with Settings, Toolbar and placeholder Dialogs.