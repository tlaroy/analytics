# v0.1.0 (2022-XX-XX)

Phase I Searches.

# v0.0.10 (2022-XX-XX)

"ItemMacro" fields.

# v0.0.9 (2022-02-18)

ID fields and ID in results.

# v0.0.8 (2022-02-09)

Cards, Compendiums, Items, Journals, Macros, Playlists, Scenes, Tables, Tiles - Forms.

# v0.0.7 (2022-02-02)

Actors - Labeling and Localization.

# v0.0.6 (2022-02-01)

Actors/Journals - Journal Searches (Phase I).
Actors/Scenes - Scene Searches (Phase I).

# v0.0.5 (2022-01-28)

Actors - Tabs and Tooltips.

# v0.0.4 (2022-01-27)

Actors - Item "On Use" Macros.

# v0.0.3 (2022-01-25)

Actors - Item options.

# v0.0.2 (2022-01-23)

Actors - Form.
Actors - Item Searches (Phase I).

# v0.0.1 (2022-01-17)

Initial alpha release. Basic module with Settings, Toolbar and placeholder Forms.
