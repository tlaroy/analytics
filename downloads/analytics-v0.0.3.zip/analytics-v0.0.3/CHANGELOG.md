# v0.0.32 (2022-1-25)

* Actor creature types, none and show Item.

# v0.0.2 (2022-1-23)

* Actors and Items Dialog. D&D5e dependency.

# v0.0.1 (2022-1-17)

* Initial release. Basic module with Settings, Toolbar and Dialogs.