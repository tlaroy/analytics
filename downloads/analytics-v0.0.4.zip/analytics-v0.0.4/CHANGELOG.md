# v0.0.4 (2022-1-27)

* Actor Item On Use Macros.

# v0.0.3 (2022-1-25)

* Actor creature types, none Item type and Show.

# v0.0.2 (2022-1-23)

* Actors and Items Dialog. D&D5e dependency.

# v0.0.1 (2022-1-17)

* Initial release. Basic module with Settings, Toolbar and placeholder Dialogs.